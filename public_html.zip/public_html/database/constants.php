<?php
session_start();

define("HOST","database-1.czvponaxmsx3.us-east-2.rds.amazonaws.com");
define("USER","admin");
define("DB","database-1");
define("PASS","password");

define("DOMAIN","Inventory-env.eba-x5wfh5is.us-east-2.elasticbeanstalk.com");

?>
